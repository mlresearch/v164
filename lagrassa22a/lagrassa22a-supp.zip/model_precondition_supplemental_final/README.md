# Videos
Videos of the robot executing plans in the real world and with illustrative examples can be found in this folder. 

If you would like to have subtitles, you can manually add the ones transcribed using your video player. 
We recommend VLC and instructions for adding subtitles can be found [here](https://wiki.videolan.org/Documentation:Subtitles/) (You will want to add a subtitle track then select it)

1. A video showing the robot executing plans with and without our method is shown in `model_preconditions_robot_video.mp4` Subtitles for this video are in `model_preconditions_robot_video_subtitles.srt`
1. An animated example shows how to plan with MDEs using only one queue for planning in `single_queue_planner_example.mp4`. Subtitles are in `single_queue_planner_example_subtitles.srt`
1. Another animated example illustrates the method in Section 4.3 using multiple queues to avoid using slower models. Subtitles are in `multiple_queue_planner_example_subtitles.srt`

# Appendix
An appendix with more experiment details and planner pseudocode is in `learning_model_preconditions_2021_appendix.pdf`. 

# Code
Code and data can be found in a public GitHub repo at [this link](https://github.com/lagrassa/model-preconditions)

