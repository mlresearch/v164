# Supplementary Material for "Influencing Behavioral Attributions to Robot Motion During Task Execution"

* `appendices.pdf`: Supplemental table and figures referenced in the paper
* `interface_explanation.mp4`: A video annotating elements of the interface and the 2D virtual home environment. All participants in our evaluative user study watched this video to familiarize themselves with the setting.
* `experiment_{I,II}/`: Videos of the trajectories used in our evaluative user study. See section 5.1 for the full description of the paremeters of their generation
* `code/`: A snapshot of the code implementing the web interfaces, models, training procedures, trajectory optimization, and data analysis. See https://github.com/nickswalker/influencing-behavioral-attributions for any post-publication updates
