# Supplementary material for "Taskography: Evaluating robot task planning over large 3D scene graphs"

Here is a brief description of the various files enclosed herewith.

taskography_supplementary.pdf - A PDF supplementary document presenting additional experiments and details that supplement the main paper
taskography_video.mp4 - A video abstract of our work (best watched with audio enabled)
captions.srt - A captions file that can be loaded into a video player for improving the accessibility of the video

Please visit our (anonymized) supplementary webpage at https://sites.google.com/view/taskography-anonymized

Note that none of the materials (webpages, videos, etc.) have been updated after the supplementary deadline (Google sites presents with a "last updated" tag, for context).

None of these materials, to the best of our knowledge, track user visits or other browsing data.
