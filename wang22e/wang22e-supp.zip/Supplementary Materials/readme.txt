Appendix.pdf
This file is the Appendix section of the paper and contains 
additional details about our model, how we handle edge cases
and parameters etc.

video
This folder contains a demo video showing additional qualitative results.
Refer to the readme file inside for more details.

code
This folder is where our codes are supposed to be. However, due to the 100MB
size limit, we have to move the codes elsewhere. Refer to the readme within 
for more details and how to access the codes.