# IMU-Assisted Learning of Single-View Rolling Shutter Correction
Follow the README in *dataset/* for dataset information and in *network/* for network training and testing.

## Samples
<img src="images/res_img.png" height="400px"/> 

## DSO on resulting images
<img src="images/dso.jpg" height="1000px"/> 