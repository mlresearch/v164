You can find videos, code, and Supplementary material on our website: https://www.robot-learning.uk/self-replay
