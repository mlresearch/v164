Videos also available at: https://hlsm-alfred.github.io/

Successful Execution Videos:
- success-secure_two_discs_in_a_bedroom_safe.mp4
- success-put_a_clean_bar_of_soap_in_the_cabinet.mp4

Failed Execution Videos:
- fail-place_the_sliced_apple_on_the_counter.mp4

Video with ground truth depth and segmentation inputs,
 demonstrating the higher-quality of resulting semantic voxel map.
- fail-gtseg-gtdepth-put_a_clean_bar_of_soap_in_the_cabinet.mp4
